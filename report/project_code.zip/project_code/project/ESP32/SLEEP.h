#ifndef SLEEP_h
#define SLEEP_h
#include "Arduino.h"
void sleepNow(int seconds);
#endif

