def request_handler(request):
	with open('__HOME__/finalProject/RH3.html', 'r') as myfile:
		return myfile.read()

		# test comment